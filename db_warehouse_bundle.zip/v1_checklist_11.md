## ⭐  V1.1+ (Bitirince Bonus, v1 için ŞART DEĞİL)

Bunlar *ekstra kas*. V1 tanımına dahil etmiyorum ama uzun vadede isteyeceksin:

- [ ]  Research job queue (SQLite + background worker, Celery/RQ vs.)
- [ ]  UI’dan full “job builder” (param aralığı slider, random search, vs.)
- [ ]  Gelişmiş raporlar:
    - [ ]  Regime-based performance (bull/bear/sideways)
    - [ ]  Intraday saatlere göre PnL
- [ ]  Telegram/Discord uyarıları (live’da kritik hatalarda DM atma)
- [ ]  Prometheus/Grafana gibi metrik entegrasyonları

---