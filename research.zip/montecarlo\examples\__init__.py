"""Monte Carlo simulation examples."""
