"""Performance attribution examples."""
