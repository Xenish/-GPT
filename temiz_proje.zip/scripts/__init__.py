"""Utility scripts package for FinanTradeAlgo."""
